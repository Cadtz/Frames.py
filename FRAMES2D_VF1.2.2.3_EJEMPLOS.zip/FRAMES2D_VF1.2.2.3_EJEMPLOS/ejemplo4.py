#Ejemplo 1 MATLAB

# Definir las coordenadas de los nodos separados por ","
x = [0, 2.5, 5] 
y = [0, 0, 0]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente
}

# Definir la carga distribuida
cargas_distribuidas = [
    (1, (-1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
    (2, (-1, 2))   # Carga distribuida para la viga 2 (magnitud, caso)
]

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main4
