""" #ESTE EJEMPLO YA FUNCIONA (Ejemplo carga puntual voladizo MATLAB)

#Ejemplo carga puntual voladizo MATLAB

bb=0
bbb=0.5

# Definir las coordenadas de los nodos separados por ","
x = [bb, 0, 0, 0.5, 1] 
y = [0, bbb, 1, 1, 1]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[i, i + 1] for i in range(1, 5)] 

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente (Empotrado)
}

# Definir la carga puntual
# Formato: [(nodo_id, [fuerza_x, fuerza_y, momento])]
cargas_puntuales = [
    (5, [0, -1, 0])  # Carga puntual aplicada en el nodo 5: fx, fy , mz  
]
# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main """
""" #ESTE EJEMPLO SOLO FUNCIONA SI PARA CARGA DISTRIBUIDA ARRIBA (-) ABAJO (+) Ejemplo 1 MATLAB (inicial)
#ESTE EJEMPLO SOLO FUNCIONA SI PARA CARGA DISTRIBUIDA ARRIBA (-) ABAJO (+)

#Ejemplo 1 MATLAB

# Definir las coordenadas de los nodos separados por ","
x = [0, 2.5, 5] 
y = [0]*3

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 res tringido completamente
}

# Definir la carga distribuida
cargas_distribuidas = [
    (1, (1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
    (2, (1, 2))   # Carga distribuida para la viga 2 (magnitud, caso)
]

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main """
""" #ESTE EJEMPLO SOLO FUNCIONA SI PARA CARGA DISTRIBUIDA ARRIBA (-) ABAJO (+) Ejemplo 1.2 MATLAB (Nuevo Archivo)
#ESTE EJEMPLO SOLO FUNCIONA SI PARA CARGA DISTRIBUIDA ARRIBA (-) ABAJO (+)
import numpy as np
#Ejemplo 1.2 MATLAB

asd = np.linspace(0,5,7)

# Definir las coordenadas de los nodos separados por ","
x = [0, 0.83333, 1.66667, 2.5, 3.3333, 4.166667, 5] 
y = [0, 0, 0, 0, 0, 0, 0]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3], [3,4],[4,5],[5,6],[6,7]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente
}

# Definir la carga distribuida
cargas_distribuidas = [
    (1, (1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
    (2, (1, 1)),   # Carga distribuida para la viga 2 (magnitud, caso)
    (3, (1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
    (4, (1, 1)),   # Carga distribuida para la viga 2 (magnitud, caso)
    (5, (1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
    (6, (1, 1)),  # Carga distribuida para la viga 2 (magnitud, caso)
    (7, (1, 2)),  # Carga distribuida para la viga 1 (magnitud, caso)
]

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main """
#Ejemplo 4.10 libro pagina 81. Convencion momento en nodo Antihorario negativo (-) YA FUNCIONA
# Definir las coordenadas de los nodos separados por ","
x = [0, 8000, 13000] #Distancias en mm
y = [0, 0, 0]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente
    2: [0, 1, 0],
    3: [1, 1, 1]   # Nodo 3 Empotrado     
}

# Definir la carga puntual
# Formato: [(nodo_id, [fuerza_x, fuerza_y, momento])]
cargas_puntuales = [
    (2, [0, 0, -50000]),  # Carga puntual aplicada en el nodo 2: fx = 0, fy = 0, mz = 0 (Carga KN)
]
E = 2000000
i2 = 50e6
a2 = 4e3
# Definir propiedades de las vigas
area = [a2,a2]  # Área de cada viga (mm2)
elastic_mod = [E,E]  # Módulo de elasticidad (Kn/mm2) de cada viga
inertia = [200e6, 50e6]  # Momento de inercia (mm^4) de cada viga

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main
 # EJEMPLO 4.9 Pag 80 SOLO FUNCIONA SI Y HACIA ABAJO (+) Y X A LA DERECHA NEGATIVO (-)
""" 
# Definir las coordenadas de los nodos separados por ","
x = [0, 8000, 13000] #Distancias en mm
y = [0, 0, 0]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente
    2: [0, 1, 0]   # Nodo 2 restringido en y 
}

# Definir la carga puntual
# Formato: [(nodo_id, [fuerza_x, fuerza_y, momento])]

cargas_puntuales = [(1, [-3.5, 3.5, 0]),  (3, [1, 4, 0])]


# Definir propiedades de las vigas
area = [6e3, 4e3]  # Área de cada viga (mm2)
elastic_mod = [200000, 200000]  # Módulo de elasticidad (Kn/mm2) de cada viga
inertia = [200e6, 50e6]  # Momento de inercia (mm^4) de cada viga

#Funcion para definir que elementos mostrar: elementos_a_mostrar
#Opciones: "matriz de rigidez global", "Matriz de rigidez local de la viga {id}"
elementos_a_mostrar = ["Matriz de rigidez global",
                       "Matriz de rigidez local de la viga 1"]

#Funcion para mostrar graficos graficos_a_mostrar.
#Opciones: "plot_frame", "plot_nodes", "plot_beam", "plot_pload"
graficos_a_mostrar = ["plot_frame", "plot_nodes"]

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main 



 """