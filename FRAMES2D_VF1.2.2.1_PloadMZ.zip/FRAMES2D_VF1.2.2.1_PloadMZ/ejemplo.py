# Definir las coordenadas de los nodos separados por ","
x = [0, 0, 0, 0.5, 1] #Distancias en mm
y = [0, 0.5, 1, 1, 1]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3], [3,4], [4,5]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente   
}

# Definir la carga puntual
# Formato: [(nodo_id, [fuerza_x, fuerza_y, momento])]
cargas_puntuales = [
    (5, [0, -1, 0])  # Carga puntual aplicada en el nodo 2: fx = 0, fy = -10, mz = 0 (Carga KN)
]
# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main
