class Nodo:
    def __init__(self, x, y, nodo_id):
        """
        Constructor para definir un nodo en un espacio euclidiano 2D.

        Parámetros:
        - x: coordenada X del nodo.
        - y: coordenada Y del nodo.
        - nodo_id: ID único del nodo.
        """
        self.id = nodo_id  # ID del nodo
        self.x = x         # Coordenada x
        self.y = y         # Coordenada y
        self.rdofs = [0, 0, 0]  # Grados de libertad restringidos [x, y, z]
        self.disp = [0, 0]      # Desplazamientos [ux, uy]
        self.nload = [0, 0]     # Cargas nodales [nlx, nly]

    def set_grados_libertad(self, grados_libertad):
        """
        Establece los grados de libertad restringidos de un nodo.

        Parámetros:
        - grados_libertad: lista [x, y, z] que define los grados de libertad restringidos.
        """
        self.rdofs = grados_libertad

    def set_carga(self, carga):
        """
        Establece la carga aplicada en un nodo.

        Parámetros:
        - carga: lista [rx, ry] que representa las fuerzas aplicadas en el nodo.
        """
        self.nload = carga

    def set_desplazamiento(self, desplazamiento):
        """
        Establece el desplazamiento en un nodo.

        Parámetros:
        - desplazamiento: lista [ux, uy] que representa los desplazamientos en el nodo.
        """
        self.disp = desplazamiento

    def __str__(self):
        """
        Representación en string del nodo.
        """
        return f"Nodo {self.id}: ({self.x}, {self.y})\n"