import matplotlib.pyplot as plt
from matplotlib.patches import Arc

def plot_carga_puntual(nodos, cargas_puntuales):
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.set_aspect('equal')

    # Graficar las vigas usando las coordenadas de cada nodo conectado
    for i in range(len(nodos) - 1):
        ax.plot([nodos[i].x, nodos[i + 1].x], [nodos[i].y, nodos[i + 1].y], 'k-', linewidth=2)
    
    # Graficar los nodos como puntos y etiquetarlos
    for i, nodo in enumerate(nodos):
        ax.plot(nodo.x, nodo.y, 'ko')  # Punto negro para el nodo
        ax.text(nodo.x, nodo.y + 100, f'N{i + 1}', ha='center', color='black')  # Etiqueta de nodo encima
    
    # Ajuste del título y etiquetas
    ax.set_title("Carga Puntual", pad=20)
    ax.set_xlabel("X (mm)")
    ax.set_ylabel("Y (mm)")
    
    # Calcular el rango de coordenadas de los nodos para definir los límites del gráfico
    x_coords = [nodo.x for nodo in nodos]
    y_coords = [nodo.y for nodo in nodos]
    x_min, x_max = min(x_coords), max(x_coords)
    y_min, y_max = min(y_coords), max(y_coords)
    margen = 0.2 * max(x_max - x_min, y_max - y_min)  # Margen adicional
    
    # Espaciado para las flechas y etiquetas
    y_offset = 0.1 * (y_max - y_min)
    x_offset = 0.1 * (x_max - x_min)
    
    for carga in cargas_puntuales:
        nodo_id, (fx, fy, mz) = carga[0], carga[1]
        nodo = nodos[nodo_id - 1]
        
        # Graficar flecha para fy (carga en Y)
        if fy != 0:
            arrow_y = nodo.y + y_offset if fy < 0 else nodo.y - y_offset
            text_y = nodo.y + 1.5 * y_offset if fy < 0 else nodo.y - 1.5 * y_offset
            arrow_scale_y = 0.1 * (y_max - y_min)
            ax.arrow(nodo.x, arrow_y, 0, fy * arrow_scale_y, head_width=0.1 * (x_max - x_min), 
                     head_length=0.1 * (y_max - y_min), fc='red', ec='red', length_includes_head=True)
            ax.text(nodo.x, text_y, f'{fy:.2f} N', color='red', ha='center', va='bottom' if fy < 0 else 'top')
        
        # Graficar flecha para fx (carga en X)
        if fx != 0:
            arrow_x = nodo.x - x_offset if fx > 0 else nodo.x + x_offset
            text_x = nodo.x - 1.5 * x_offset if fx > 0 else nodo.x + 1.5 * x_offset
            arrow_scale_x = 0.1 * (x_max - x_min)
            ax.arrow(arrow_x, nodo.y, fx * arrow_scale_x, 0, head_width=0.1 * (y_max - y_min), 
                     head_length=0.1 * (x_max - x_min), fc='blue', ec='blue', length_includes_head=True)
            ax.text(text_x, nodo.y, f'{fx:.2f} N', color='blue', ha='center', va='center')
        
        # Graficar arco para mz (momento en Z)
        if mz != 0:
            radius = 0.3 * (y_max - y_min)
            theta1, theta2 = (0, 270) if mz > 0 else (0, -270)
            arc = Arc((nodo.x, nodo.y), radius, radius, angle=0, theta1=theta1, theta2=theta2, 
                      color='purple', lw=2)
            ax.add_patch(arc)
            ax.text(nodo.x, nodo.y - 1.2 * radius, f'{mz:.2f} Nm', color='purple', ha='center')
    
    # Establecer límites del gráfico para ajustarse a la estructura completa
    ax.set_xlim(x_min - margen, x_max + margen)
    ax.set_ylim(y_min - margen, y_max + margen)
    
    ax.grid(True)
    plt.show()
