from node.node import Nodo
from beam.beam import Viga
from wload.wload import CargaDistribuida
from wload.nodalLoads import nodal_loads
from frame.frame import Marco
from frame.solveStatic import solve_static

# Definir las coordenadas de los nodos separados por ","
x = [0, 2.5, 5]
y = [0, 0, 0]

    # Crear nodos usando la clase Nodo
nodos = []
for i in range(len(x)):
    nodos.append(Nodo(x[i], y[i], i + 1))  # Nodo recibe x, y, y un ID
    # Empotrar el nodo 1 (restringir los 3 grados de libertad)
nodos[0].set_grados_libertad([1, 1, 1])

    # Crear vigas usando la clase Viga
    # node_ids son los pares de nodos [nodo inicial, nodo final] para cada viga
node_ids = [[1, 2], [2, 3]]
vigas_obj = Viga(nodos, node_ids)

    # Acceder a las vigas generadas
vigas = vigas_obj.vigas

    # Generar las cargas distribuidas usando la clase CargaDistribuida
cargas_distribuidas = [
    CargaDistribuida([vigas[0]], [-1], 1),  # Caso 1: empotrado-empotrado
    CargaDistribuida([vigas[1]], [-1], 2)   # Caso 2: voladizo
    ]

    # Calcular las cargas nodales equivalentes a las distribuidas
q_nodal = nodal_loads(cargas_distribuidas, vigas)

    # Crear el marco estructural usando la clase Marco
marco = Marco(nodos, vigas, cargas_distribuidas)

    # Resolver el problema estático
marco_resuelto = solve_static(marco, print_output=True)

    # Imprimir los resultados
print("\nResultados finales del análisis estructural:")
print(marco_resuelto)