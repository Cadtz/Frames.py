# Definir las coordenadas de los nodos separados por ","
x = [0, 2.5, 5]
y = [0, 0, 0]
# Empotrar el nodo 1 (restringir los 3 grados de libertad)
nodos[0].set_grados_libertad([1, 1, 1])
# Crear vigas usando la clase Viga
# node_ids son los pares de nodos [nodo inicial, nodo final] para cada viga
node_ids = [[1, 2], [2, 3]]
vigas_obj = Viga(nodos, node_ids)
# Generar las cargas distribuidas usando la clase CargaDistribuida
cargas_distribuidas = [
    CargaDistribuida([vigas[0]], [-1], 1),  # Caso 1: empotrado-empotrado
    CargaDistribuida([vigas[1]], [-1], 2)   # Caso 2: voladizo
]
from Main import Main
Main()