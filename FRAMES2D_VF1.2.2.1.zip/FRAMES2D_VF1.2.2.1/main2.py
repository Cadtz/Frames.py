from ejemplo import x, y, node_ids
try:
    from ejemplo import grados_libertad
except ImportError:
    grados_libertad = {}  # Valor por defecto si no se define en el archivo ejemplo
try:
    from ejemplo import cargas_distribuidas
except ImportError:
    cargas_distribuidas = []  # Valor por defecto si no se define en el archivo ejemplo

try:
    from ejemplo import cargas_puntuales
except ImportError:
    cargas_puntuales = []  # Valor por defecto si no se define en el archivo ejemplo

from node.node import Nodo
from beam.beam import Viga
from wload.wload import CargaDistribuida
from pload.pload import CargaPuntual
from wload.nodalLoads import nodal_loads
from frame.frame import Marco
from frame.solveStatic import solve_static
from beam.plot import plot_beam
from node.plot import plot_nodes
from frame.plot import plot_frame_diagrams

# Crear nodos usando la clase Nodo
nodos = []
for i in range(len(x)):
    nodos.append(Nodo(x[i], y[i], i + 1))  # Nodo recibe x, y, y un ID

# Aplicar grados de libertad definidos en el archivo ejemplo
if grados_libertad:
    for i, grados in grados_libertad.items():
        nodos[i - 1].set_grados_libertad(grados)  # Los IDs de los nodos empiezan desde 1

# Crear vigas usando la clase Viga
try:
    from ejemplo import area, elastic_mod, inertia
except ImportError:
    area, elastic_mod, inertia = None, None, None  # Valores por defecto si no se definen en ejemplo

if area is None and elastic_mod is None and inertia is None:
    vigas_obj = Viga(nodos, node_ids)
elif area is not None and elastic_mod is None and inertia is None:
    vigas_obj = Viga(nodos, node_ids, area)
elif area is not None and elastic_mod is not None and inertia is None:
    vigas_obj = Viga(nodos, node_ids, area, elastic_mod)
else:
    vigas_obj = Viga(nodos, node_ids, area, elastic_mod, inertia)

# Acceder a las vigas generadas
vigas = vigas_obj.vigas

# Generar la carga distribuida usando la clase CargaDistribuida para cada tramo si existen cargas distribuidas
cargas_distribuidas_obj = []
if cargas_distribuidas:
    cargas_distribuidas_obj = [
        CargaDistribuida([vigas[i]], [cargas_distribuidas[i][0]], cargas_distribuidas[i][1]) for i in range(len(vigas))
    ]

# Generar la carga puntual usando la clase CargaPuntual si existen cargas puntuales
cargas_puntuales_obj = []
if cargas_puntuales:
    cargas_puntuales_obj = [
    CargaPuntual(nodos, [carga[0]], [carga[1][:2]]) for carga in cargas_puntuales
]

# Crear el marco estructural usando la clase Marco
if not cargas_puntuales_obj and not cargas_distribuidas_obj:
    marco = Marco(nodos, vigas)
elif not cargas_puntuales_obj:
    marco = Marco(nodos, vigas, cargas_distribuidas_obj)
elif not cargas_distribuidas_obj:
    marco = Marco(nodos, vigas, cargas_puntuales_obj)
else:
    marco = Marco(nodos, vigas, cargas_puntuales_obj, cargas_distribuidas_obj)

# Resolver el problema estático
marco_resuelto = solve_static(marco, print_output=True)

# Imprimir los resultados
print("\nResultados finales del análisis estructural:")
print(marco_resuelto)

# Graficar los nodos y vigas
plot_nodes(nodos)
plot_beam(nodos, vigas)

# Extraer las propiedades de las vigas resueltas y preparar para graficar los diagramas
vigas_data = []
for viga in vigas:
    vigas_data.append({
        'id': viga['id'],
        'shearLoad': viga['shearLoad'],
        'bendingMoment': viga['bendingMoment'],
        'axialLoad': viga['axialLoad'] if isinstance(viga['axialLoad'], (int, float)) else viga['axialLoad'][0],
        'len': viga['len']
    })

# Graficar los diagramas de fuerza cortante, momento flector y fuerza axial
plot_frame_diagrams(vigas_data)
