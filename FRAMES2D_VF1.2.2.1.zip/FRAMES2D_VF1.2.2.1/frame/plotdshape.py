import matplotlib.pyplot as plt

def plot_deformed_shape(nodos, escala=1.0):
    """
    Grafica la forma deformada del pórtico después del análisis estático.
    
    Parámetros:
    - nodos: lista de nodos después del desplazamiento.
    - escala: factor de escala para amplificar las deformaciones.
    """
    fig, ax = plt.subplots()
    
    # Graficar la posición original y desplazada de cada nodo
    for nodo in nodos:
        x_orig, y_orig = nodo.x, nodo.y
        x_def, y_def = x_orig + nodo.dx * escala, y_orig + nodo.dy * escala
        
        # Dibujar la viga original
        ax.plot([x_orig, x_def], [y_orig, y_def], 'k--', linewidth=1, label="Posición Original" if nodo == nodos[0] else "")
        
        # Dibujar la viga deformada
        ax.plot(x_def, y_def, 'ro', label="Posición Deformada" if nodo == nodos[0] else "")
    
    ax.set_aspect('equal')
    plt.title("Forma Deformada del Pórtico")
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")
    plt.grid(True)
    plt.legend()
    plt.show()
