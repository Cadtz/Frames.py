import matplotlib.pyplot as plt
import numpy as np

def plot_shear_force(vigas):
    """
    Grafica el diagrama de fuerza cortante para cada viga del marco.

    Parámetros:
    - vigas: Lista de diccionarios que contiene las propiedades de cada viga, incluyendo la fuerza cortante.
    """
    plt.figure(figsize=(10, 6))
    for viga in vigas:
        # Extraer las fuerzas cortantes en los nodos inicial y final
        shear_load = viga['shearLoad']
        length = viga['len']

        # Coordenadas para el diagrama de cortante
        x = [0, length]
        y = [shear_load[0], shear_load[1]]

        plt.plot(x, y, label=f"Viga {viga['id']}")
        plt.fill_between(x, y, color='skyblue', alpha=0.2)

    plt.xlabel("Longitud de la Viga (m)")
    plt.ylabel("Fuerza Cortante (N)")
    plt.title("Diagrama de Fuerza Cortante")
    plt.axhline(0, color='black', lw=0.5)
    plt.grid(True)
    plt.legend()
    plt.show()

def plot_bending_moment(vigas):
    """
    Grafica el diagrama de momento flector para cada viga del marco.

    Parámetros:
    - vigas: Lista de diccionarios que contiene las propiedades de cada viga, incluyendo el momento flector.
    """
    plt.figure(figsize=(10, 6))
    for viga in vigas:
        # Extraer los momentos flectores en los nodos inicial y final
        bending_moment = viga['bendingMoment']
        length = viga['len']

        # Coordenadas para el diagrama de momento flector
        x = [0, length]
        y = [bending_moment[0], bending_moment[1]]

        plt.plot(x, y, label=f"Viga {viga['id']}")
        plt.fill_between(x, y, color='lightgreen', alpha=0.2)

    plt.xlabel("Longitud de la Viga (m)")
    plt.ylabel("Momento Flector (Nm)")
    plt.title("Diagrama de Momento Flector")
    plt.axhline(0, color='black', lw=0.5)
    plt.grid(True)
    plt.legend()
    plt.show()

def plot_axial_force(vigas):
    """
    Grafica el diagrama de fuerza axial para cada viga del marco.

    Parámetros:
    - vigas: Lista de diccionarios que contiene las propiedades de cada viga, incluyendo la fuerza axial.
    """
    plt.figure(figsize=(10, 6))
    for viga in vigas:
        # Extraer las fuerzas axiales en los nodos inicial y final
        axial_load = viga['axialLoad']
        length = viga['len']

        # Coordenadas para el diagrama de fuerza axial
        x = [0, length]
        y = [axial_load, axial_load]  # La fuerza axial se considera constante a lo largo de la viga

        plt.plot(x, y, label=f"Viga {viga['id']}")
        plt.fill_between(x, y, color='salmon', alpha=0.2)

    plt.xlabel("Longitud de la Viga (m)")
    plt.ylabel("Fuerza Axial (N)")
    plt.title("Diagrama de Fuerza Axial")
    plt.axhline(0, color='black', lw=0.5)
    plt.grid(True)
    plt.legend()
    plt.show()

def plot_frame_diagrams(vigas):
    """
    Grafica los diagramas de fuerza cortante, momento flector y fuerza axial para cada viga del marco.

    Parámetros:
    - vigas: Lista de diccionarios que contiene las propiedades de cada viga.
    """
    plot_shear_force(vigas)
    plot_bending_moment(vigas)
    plot_axial_force(vigas)

# Ejemplo de uso (suponiendo que vigas es una lista de diccionarios con las propiedades de cada viga)
# vigas = [
#     {'id': 1, 'shearLoad': [500, -500], 'bendingMoment': [-1000, 0], 'axialLoad': -1000, 'len': 2.0},
#     {'id': 2, 'shearLoad': [300, -300], 'bendingMoment': [-500, 500], 'axialLoad': 800, 'len': 1.5}
# ]
# plot_frame_diagrams(vigas)
