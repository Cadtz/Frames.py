import matplotlib.pyplot as plt

def plot_beam(nodos, vigas):
    """
    Función para graficar nodos y vigas en el espacio 2D.

    Parámetros:
    - nodos: lista de objetos Nodo.
    - vigas: lista de vigas.
    """
    fig, ax = plt.subplots()

    # Graficar nodos
    x = [nodo.x for nodo in nodos]
    y = [nodo.y for nodo in nodos]
    ax.scatter(x, y, c='black')

    # Añadir etiquetas a los nodos
    for nodo in nodos:
        ax.text(nodo.x, nodo.y, f'N{nodo.id}', fontsize=9, ha='left')

    # Graficar vigas
    for viga in vigas:
        nodo_inicial = nodos[viga['ni'] - 1]
        nodo_final = nodos[viga['nj'] - 1]
        x_coords = [nodo_inicial.x, nodo_final.x]
        y_coords = [nodo_inicial.y, nodo_final.y]
        ax.plot(x_coords, y_coords, 'b-')
        
        # Añadir etiquetas a las vigas
        mid_x = (nodo_inicial.x + nodo_final.x) / 2
        mid_y = (nodo_inicial.y + nodo_final.y) / 2
        ax.text(mid_x, mid_y, f'V{viga["id"]}', fontsize=9, ha='center')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title('Gráfico de Nodos y Vigas')
    ax.grid(True)
    plt.show()
