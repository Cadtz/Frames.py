from node.node import Nodo
from beam.beam import Viga
from wload.wload import CargaDistribuida
from wload.nodalLoads import nodal_loads
from frame.frame import Marco
from frame.solveStatic import solve_static
from beam.plot import plot_beam
from node.plot import plot_nodes
from frame.plot import plot_frame_diagrams

# Definir las coordenadas de los nodos separados por ","
x = [0, 5, 10]
y = [0, 0, 0]

# Crear nodos usando la clase Nodo
nodos = []
for i in range(len(x)):
    nodos.append(Nodo(x[i], y[i], i + 1))  # Nodo recibe x, y, y un ID

# Empotrar el nodo 1 y el nodo 3 (restringir los 3 grados de libertad)
nodos[0].set_grados_libertad([1, 1, 1])
nodos[2].set_grados_libertad([1, 1, 1])

# Crear vigas usando la clase Viga
node_ids = [[1, 2], [2, 3]]
vigas_obj = Viga(nodos, node_ids)

# Acceder a las vigas generadas
vigas = vigas_obj.vigas

# Generar la carga distribuida usando la clase CargaDistribuida para cada tramo
cargas_distribuidas = [
    CargaDistribuida([vigas[0]], [-1], 1), # Caso 1: empotrado-empotrado
    CargaDistribuida([vigas[1]], [-1], 1)  # Caso 1: empotrado-empotrado
]

# Generar las cargas nodales a partir de la carga distribuida
q_nodal = nodal_loads(cargas_distribuidas, vigas)

# Crear el marco estructural usando la clase Marco
marco = Marco(nodos, vigas, cargas_distribuidas)

# Resolver el problema estático
marco_resuelto = solve_static(marco, print_output=True)

# Imprimir los resultados
print("\nResultados finales del análisis estructural:")
print(marco_resuelto)

# Graficar los nodos y vigas
plot_nodes(nodos)
plot_beam(nodos, vigas)

# Extraer las propiedades de las vigas resueltas y preparar para graficar los diagramas
vigas_data = []
for viga in vigas:
    vigas_data.append({
        'id': viga['id'],
        'shearLoad': viga['shearLoad'],
        'bendingMoment': viga['bendingMoment'],
        'axialLoad': viga['axialLoad'] if isinstance(viga['axialLoad'], (int, float)) else viga['axialLoad'][0],
        'len': viga['len']
    })

# Graficar los diagramas de fuerza cortante, momento flector y fuerza axial
plot_frame_diagrams(vigas_data)
