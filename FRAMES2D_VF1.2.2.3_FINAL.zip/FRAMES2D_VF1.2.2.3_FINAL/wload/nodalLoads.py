import numpy as np

def nodal_loads(cargas_distribuidas, vigas):
    """
    Calcula las cargas nodales equivalentes a partir de las cargas distribuidas sobre vigas.

    Parámetros:
    - cargas_distribuidas: Lista o un único objeto CargaDistribuida que aplica cargas sobre las vigas.
    - vigas: Lista de objetos que representan las vigas.

    Retorna:
    - p: Matriz 3x2xn con las cargas nodales en coordenadas locales, donde n es el número de cargas distribuidas.
    """
    if not isinstance(cargas_distribuidas, list):
        # Si no es una lista, lo convertimos en una lista de un solo elemento
        cargas_distribuidas = [cargas_distribuidas]

    nw = len(cargas_distribuidas)
    p = np.zeros((nw, 3, 2))  # Inicializar matriz de cargas nodales

    for i in range(nw):
        q = loading_cases(cargas_distribuidas[i], vigas)
        p[i, :, :] = q

    return p

def loading_cases(carga_distribuida, vigas):
    """
    Calcula las cargas nodales equivalentes para un caso de carga específico en una viga.

    Parámetros:
    - carga_distribuida: Objeto que representa la carga distribuida en una viga específica.
    - vigas: Lista de objetos viga que representan las vigas.

    Retorna:
    - q: Matriz 3x2 con las cargas nodales equivalentes en coordenadas locales.
    """
    fid = carga_distribuida.beamId[0]  # ID de la viga (ajusta si se espera una lista)
    L = vigas[fid - 1]['len']  # Longitud de la viga
    caso = carga_distribuida.caso
    w = carga_distribuida.valores_carga[0]  # Valor de la carga

    q = np.zeros((3, 2))

    if caso == 1:
        # Carga distribuida en toda la longitud de la viga (empotrado-empotrado)
        q[1, :] = -w * L / 2
        q[2, :] = w * L**2 / 12 *np.array([-1, 1])
    elif caso == 2:
        # Carga distribuida en toda la longitud de la viga (voladizo)
        q[1, 0] = -w * L
        q[2, 0] = -w * L**2 / 2

    return q
    
    