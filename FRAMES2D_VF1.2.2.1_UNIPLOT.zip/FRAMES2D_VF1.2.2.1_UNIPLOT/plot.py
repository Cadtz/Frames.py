import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np

import matplotlib.pyplot as plt

def plot_frame(nodos, vigas):
    """
    Función para graficar el marco estructural con nodos y vigas.
    """
    fig, ax = plt.subplots()

    # Graficar nodos
    x = [nodo.x for nodo in nodos]
    y = [nodo.y for nodo in nodos]
    ax.scatter(x, y, c='black')  # Nodos

    # Graficar vigas
    for viga in vigas:
        nodo_inicial = nodos[viga['ni'] - 1]
        nodo_final = nodos[viga['nj'] - 1]
        x_coords = [nodo_inicial.x, nodo_final.x]
        y_coords = [nodo_inicial.y, nodo_final.y]
        ax.plot(x_coords, y_coords, 'k-', linewidth=2)  # Dibujar vigas en negro
        
    ax.set_xlabel("X (mm)")
    ax.set_ylabel("Y (mm)")
    ax.grid(True)
   
    return fig, ax


def plot_nodes(nodos):
    # Graficar nodos
    x = [nodo.x for nodo in nodos]
    y = [nodo.y for nodo in nodos]
    plt.scatter(x, y, c='red')
    
    # Añadir etiquetas a los nodos
    for nodo in nodos:
        plt.text(nodo.x, nodo.y, f'N{nodo.id}', fontsize=9, ha='left')
    plt.title("Gráfico de Nodos")
    plt.xlabel("X (mm)")
    plt.ylabel("Y (mm)")

def plot_beam(nodos, vigas):
    # Graficar nodos
    x = [nodo.x for nodo in nodos]
    y = [nodo.y for nodo in nodos]
    plt.scatter(x, y, c='red')
    
    # Añadir etiquetas a los nodos
    for nodo in nodos:
        plt.text(nodo.x, nodo.y, f'N{nodo.id}', fontsize=9, ha='left')
    # Graficar vigas
    for viga in vigas:
        nodo_inicial = nodos[viga['ni'] - 1]
        nodo_final = nodos[viga['nj'] - 1]
        x_coords = [nodo_inicial.x, nodo_final.x]
        y_coords = [nodo_inicial.y, nodo_final.y]
        plt.plot(x_coords, y_coords, 'blue')
        
        # Añadir etiquetas a las vigas
        mid_x = (nodo_inicial.x + nodo_final.x) / 2
        mid_y = (nodo_inicial.y + nodo_final.y) / 2
        plt.text(mid_x, mid_y, f'V{viga["id"]}', fontsize=9, ha='center')
    plt.title("Gráfico de Nodos y Vigas")
    plt.xlabel("X (mm)")
    plt.ylabel("Y (mm)")

def plot_pload(nodos, vigas, cargas_puntuales_obj):
    """
    Función para graficar el marco estructural y las cargas puntuales en los nodos.
    """
    # Llamar a plot_frame para crear el marco estructural
    fig, ax = plot_frame(nodos, vigas)
    
    # Añadir las cargas puntuales a la figura
    for carga in cargas_puntuales_obj:
        for carga_info in carga.cargas:
            nodo_id = carga_info['nodo']
            px, py, mz = carga_info['valor']
            nodo = next(n for n in nodos if n.id == nodo_id)  # Nodo donde se aplica la carga
            
            # Dibujar flecha para carga en X
            if px != 0:
                x_offset = 0.1 * np.sign(px)
                plt.arrow(nodo.x - x_offset, nodo.y, px * 0.001, 0, head_width=1, head_length=1, color='blue')
                plt.text(nodo.x - x_offset, nodo.y - 0.2, f'{px:.2f}', color='blue', ha='center')
            
            # Dibujar flecha para carga en Y
            if py != 0:
                y_offset = 0.1 * np.sign(py)
                plt.arrow(nodo.x, nodo.y - y_offset, 0, py * 0.001, head_width=1, head_length=1, color='red')
                plt.text(nodo.x, nodo.y - y_offset - 0.3, f'{py:.2f}', color='red', ha='center')

            # Dibujar momento como arco
            if mz != 0:
                arc_direction = -1 if mz < 0 else 1
                arc = patches.Arc((nodo.x, nodo.y), 1, 1, angle=0, theta1=0, theta2=180 * arc_direction, color='purple', lw=2)
                ax.add_patch(arc)
                ax.text(nodo.x, nodo.y + 0.5 * arc_direction, f'{mz:.2f}', color='purple', ha='center')
    plt.title("Carga Puntual")
    plt.show()

