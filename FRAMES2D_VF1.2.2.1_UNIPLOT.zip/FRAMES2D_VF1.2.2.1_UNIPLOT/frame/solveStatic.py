import numpy as np
from frame.stiffness import stiffness
from wload.nodalLoads import nodal_loads
from beam.beamDirCosines import beam_dir_cosines
from beam.beamStiffness import beam_stiffness

def solve_static(frame, print_output=False):
    """
    Resuelve el problema estático para el marco, calculando los desplazamientos, reacciones
    y cargas internas de las vigas.

    Parámetros:
    - frame: Diccionario que contiene los nodos (frame['n']), las vigas (frame['b']),
             y las cargas (frame['p'] y frame['w']).
    - print_output: Booleano para decidir si se imprimen los resultados (desactivado por defecto).

    Retorna:
    - frame: El mismo marco con los resultados (desplazamientos, reacciones y cargas internas actualizados).
    """

    # Cargar nodos y grados de libertad
    nodos = frame.n
    nx = len(nodos)
    rdofs = np.array([nodo.rdofs for nodo in nodos], dtype=bool).flatten()  # Grados de libertad restringidos
    adofs = ~rdofs  # Grados de libertad activos (no restringidos)

    # Ensamblar el vector de cargas {p}
    p = np.zeros(len(rdofs)) # Inicializa el vector de cargas p en ceros
    d = np.zeros(len(rdofs)) 
    
    # ENSAMBLA LAS CARGAS PUNTUALES DEFINIDAS POR EL USUARIO
    ploads = frame.p
    for carga_puntual in ploads:  # 'carga_puntual' es una instancia de CargaPuntual
        for pload in carga_puntual.cargas:  # 'pload' es un diccionario con las claves 'nodo' y 'valor'
            ni = pload['nodo'] - 1  # Índice del nodo (ajustado a 0 para Python)
            idofs = range(ni * 3, ni * 3 + 3)  # Grados de libertad del nodo en p
        
            # Verifica el valor de carga y ajusta si es necesario
            if isinstance(pload['valor'], (list, np.ndarray)) and len(pload['valor']) == 3:
                # Ajusta la carga a un formato de 3 componentes [px, py, mz]
                p[idofs] += np.array(pload['valor'])
            else:
                raise ValueError(f"La carga puntual en el nodo {ni+1} debe tener 3 componentes.")

    # ENSAMBLA LAS CARGAS NODALES EQUIVALENTES A PARTIR DE LAS CARGAS DISTRIBUIDAS
    wloads = frame.w
    q = np.zeros((len(frame.b), 3, 2))  # Matriz de cargas nodales para cada viga
    for wload in wloads:
        # Calcula qi, las cargas nodales equivalentes de la carga distribuida wload
        qi = nodal_loads(wload, frame.b)
        beam_indices = np.array(wload.beamId) - 1  # Convertimos a índice de Python (restando 1)
        q[beam_indices, :, :] = qi
        
        # Aplica las cargas a cada viga específica mencionada en beamId
        for beam_id in wload.beamId:
            beam = frame.b[beam_id - 1]  # Accede a la viga usando beam_id
            T = beam_dir_cosines(beam, nodos)  # Matriz de transformación T de la viga
            
            # Índices de grados de libertad de los nodos de la viga beam_id
            ni = beam['ni'] - 1
            nj = beam['nj'] - 1
            idofs = list(range(ni * 3, ni * 3 + 3))  # DOFs del nodo inicial
            jdofs = list(range(nj * 3, nj * 3 + 3))  # DOFs del nodo final
            dofs = idofs + jdofs  # DOFs combinados de la viga
            
            # Aplica la carga equivalente qi en coordenadas globales usando T
            T_t = np.transpose(T)
            qqq_i = qi.flatten(order='F')
            p[np.ix_(dofs)] += T_t @ qqq_i

    # Resolver los desplazamientos {d} si hay cargas
    if np.any(np.abs(p) > 0):
        k_global = stiffness(frame)
        active_dof_stiffness = k_global[np.ix_(adofs, adofs)]
        active_dof_forces = p[adofs]

        print("Tamaño de active_dof_stiffness:", active_dof_stiffness.shape)
        print("Tamaño de active_dof_forces:", active_dof_forces.shape)

        # Use pseudo-inverse to handle singular matrix cases
        d[adofs] = np.linalg.solve(active_dof_stiffness, active_dof_forces)

        # Resolver las reacciones {R}
        p[rdofs] += -1 * k_global[np.ix_(rdofs, adofs)] @ d[adofs]

    # Calcular las cargas internas en las vigas
    for i, viga in enumerate(frame.b):
        ni = viga['ni'] - 1
        nj = viga['nj'] - 1
        idofs = range(ni * 3, ni * 3 + 3)
        jdofs = range(nj * 3, nj * 3 + 3)
        dofs = list(idofs) + list(jdofs)

        # Transformar desplazamientos a coordenadas locales
        T = beam_dir_cosines(viga, nodos)
        di = T @ d[np.ix_(dofs)]
        kl = beam_stiffness(viga)

        # Cargas internas en coordenadas locales
        pn = q[i, :, :]
        pi = kl @ di - pn.flatten(order='F')
        pi = pi.reshape((3, 2), order='F')
        pi = np.round(pi, decimals=10)
        
        # Actualizar las propiedades de la viga y convertir momentos a kNm
        viga['axialLoad'] = -pi[0]
        viga['shearLoad'] = -pi[1, :]
        viga['bendingMoment'] = -pi[2, :]

    # Actualizar los desplazamientos y reacciones en los nodos
   # Actualizar los desplazamientos y reacciones en los nodos
    d = d.reshape((nx, 3))
    p = p.reshape((nx, 3))
    for i, nodo in enumerate(nodos):
    # Convertimos p[i][2] (momento en rz) de Nmm a kNm
        nodo.nload = np.array([-p[i][0], -p[i][1], -p[i][2]])
        nodo.disp = d[i]


    # Imprimir los resultados si es necesario
    if print_output:
        print_static_data(frame)

    return frame



def print_static_data(frame):
    """
    Imprime los resultados de las cargas internas, reacciones y desplazamientos en el marco.
    """
    print("\nCargas internas en las vigas:")
    for viga in frame.b:
        print(f"Viga {viga['id']}:"
              f"\tAxial = {viga['axialLoad']}"
              f"\tShear = {viga['shearLoad']}"
              f"\tBending = {viga['bendingMoment']}")

    print("\nReacciones en los nodos:")
    for nodo in frame.n:
        if any(nodo.rdofs):
            print(f"Nodo {nodo.id}:"
                  f"\trx = {nodo.nload[0]:.6f},"
                  f" ry = {nodo.nload[1]:.6f},"
                  f" rz = {nodo.nload[2]:.6f}")

    print("\nDesplazamientos en los nodos:")
    for nodo in frame.n:
        print(f"Nodo {nodo.id}:"
              f"\tux = {nodo.disp[0]:.6f},"
              f" uy = {nodo.disp[1]:.6f},"
              f" rz = {nodo.disp[2]:.6f}")
    
    print("\nPropiedades de las vigas:")
    for viga in frame.b:
        print(f"Viga {viga['id']} - Área: {viga['area']},"
              f" Módulo de Elasticidad: {viga['elasticMod']},"
              f" Inercia: {viga['inertia']}")

