import matplotlib.pyplot as plt
import numpy as np

def plot_carga_distribuida(vigas, nodos, cargas_distribuidas):
    """
    Plotea las cargas distribuidas sobre las vigas.

    Parámetros:
    - vigas: Lista de vigas en el marco.
    - nodos: Lista de nodos en el marco.
    - cargas_distribuidas: Cargas distribuidas aplicadas a las vigas.
    """
    plt.figure()
    plt.title("Carga Distribuida")
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")
    plt.axhline(0, color='black', lw=2)  # Dibuja la línea base de la viga

    # Plotea cada viga
    for viga in vigas:
        ni = viga['ni'] - 1  # Índice del nodo inicial
        nj = viga['nj'] - 1  # Índice del nodo final
        x = [nodos[ni].x, nodos[nj].x]
        y = [nodos[ni].y, nodos[nj].y]
        plt.plot(x, y, 'k-', linewidth=2)

        # Plotea las cargas distribuidas
        for carga in cargas_distribuidas:
            if carga[0] == viga['id']:  # Verifica si la carga se aplica a esta viga
                magnitud = carga[1][0]  # Magnitud de la carga distribuida
                num_flechas = 10  # Número de flechas a mostrar
                x_pos = np.linspace(x[0], x[1], num_flechas)  # Posiciones a lo largo de la viga
                y_pos = np.zeros(num_flechas)  # Todas las flechas empiezan en y=0

                # Plotea las flechas
                for x in x_pos:
                    plt.arrow(x, 0, 0, magnitud*0.1, head_width=0.1, head_length=0.2, fc='blue', ec='blue')

                # Muestra la magnitud de la carga distribuida
                plt.text((x[0] + x[1]) / 2, 0.05, f"{magnitud} N/m", ha='center', va='bottom', color='blue')

    plt.axis('equal')
    plt.grid()
    plt.show()
