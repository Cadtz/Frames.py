# Definir las coordenadas de los nodos separados por ","
x = [0, 8000, 13000] #Distancias en mm
y = [0, 0, 0]

# Definir las conectividades de las vigas (nodos que une cada viga)
node_ids = [[1, 2], [2, 3]]

# Definir los grados de libertad restringidos para los nodos
# Formato: {nodo_id: [dx, dy, rotacion]}
# 1 = restringido, 0 = libre
grados_libertad = {
    1: [1, 1, 1],  # Nodo 1 restringido completamente
    2: [0, 1, 0]   # Nodo 2 restringido en y 
}

# Definir la carga distribuida
#cargas_distribuidas = [
#    (1, (-1, 1)),  # Carga distribuida para la viga 1 (magnitud, caso)
#    (2, (-1, 2))   # Carga distribuida para la viga 2 (magnitud, caso)
#]

# Definir la carga puntual
# Formato: [(nodo_id, [fuerza_x, fuerza_y, momento])]

cargas_puntuales = [
    (3, [3.535, -3.535, 0])  # Carga puntual aplicada en el nodo 2: fx = 0, fy = -10, mz = 0 (Carga KN)
]

# Definir propiedades de las vigas
area = [6e3, 4e3]  # Área de cada viga (mm2)
elastic_mod = [200000, 200000]  # Módulo de elasticidad (Kn/mm2) de cada viga
inertia = [200e6, 50e6]  # Momento de inercia (mm^4) de cada viga

# Ejecutar el análisis estructural importando y llamando a main
if __name__ == "__main__":
    import Main
