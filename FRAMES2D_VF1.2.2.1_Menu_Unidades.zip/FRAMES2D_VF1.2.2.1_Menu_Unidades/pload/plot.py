import matplotlib.pyplot as plt

def plot_carga_puntual(nodos, cargas_puntuales):
    fig, ax = plt.subplots()
    ax.set_aspect('equal')
    
    # Graficar la viga como una línea negra entre los nodos
    for i in range(len(nodos) - 1):
        ax.plot([nodos[i].x, nodos[i + 1].x], [nodos[i].y, nodos[i + 1].y], 'k-', linewidth=2)
    
    # Graficar los nodos como puntos y etiquetarlos
    for i, nodo in enumerate(nodos):
        ax.plot(nodo.x, nodo.y, 'ko')  # Punto negro para el nodo
        ax.text(nodo.x, nodo.y + 0.1, f'N{i + 1}', ha='center', color='black')  # Etiqueta de nodo encima
    
    # Ajuste del título y etiquetas
    ax.set_title("Carga Puntual", pad=20)
    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    
    # Calcular el rango de coordenadas de los nodos
    x_coords = [nodo.x for nodo in nodos]
    y_coords = [nodo.y for nodo in nodos]
    x_min, x_max = min(x_coords), max(x_coords)
    y_min, y_max = min(y_coords), max(y_coords)
    
    # Margen adicional para evitar que las flechas queden en el borde
    margen = 0.2 * max(x_max - x_min, y_max - y_min)
    
    # Ajuste de la separación vertical para la flecha
    y_offset = 0.2  # Espacio entre la viga y la flecha para que se ubique arriba o abajo
    x_offset = 0.2  # Espacio para las flechas horizontales a la derecha o izquierda del nodo
    
    for carga in cargas_puntuales:
        nodo_id, (fx, fy) = carga[0], carga[1]
        nodo = nodos[nodo_id - 1]
        
        # Graficar flecha para fy (carga en Y)
        if fy != 0:
            if fy < 0:
                arrow_y = nodo.y + y_offset
                text_y = nodo.y + y_offset + 0.05
            else:
                arrow_y = nodo.y - y_offset
                text_y = nodo.y - y_offset - 0.05

            arrow_scale_y = 0.15  # Escala para la longitud de la flecha en Y
            ax.arrow(
                nodo.x, arrow_y, 0, fy * arrow_scale_y,
                head_width=0.1, head_length=0.1, fc='red', ec='red', length_includes_head=True
            )
            ax.text(nodo.x, text_y, f'{fy:.2f} N', color='red', ha='center', va='bottom' if fy < 0 else 'top')
        
        # Graficar flecha para fx (carga en X)
        if fx != 0:
            if fx > 0:
                arrow_x = nodo.x - x_offset
                text_x = nodo.x - x_offset - 0.1
            else:
                arrow_x = nodo.x + x_offset
                text_x = nodo.x + x_offset + 0.1

            arrow_scale_x = 0.15  # Escala para la longitud de la flecha en X
            ax.arrow(
                arrow_x, nodo.y, fx * arrow_scale_x, 0,
                head_width=0.1, head_length=0.1, fc='blue', ec='blue', length_includes_head=True
            )
            ax.text(text_x, nodo.y, f'{fx:.2f} N', color='blue', ha='center', va='center')

    # Establecer límites automáticos según las coordenadas de los nodos
    ax.set_xlim(x_min - margen, x_max + margen)
    ax.set_ylim(y_min - margen, y_max + margen)
    
    # Ocultar la grilla en el eje Y para que no se extienda hasta la flecha
    ax.grid(True)
    ax.yaxis.grid(False)
    
    plt.show()
