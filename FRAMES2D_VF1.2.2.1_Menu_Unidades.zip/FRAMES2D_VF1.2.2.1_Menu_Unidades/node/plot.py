import matplotlib.pyplot as plt

def plot_nodes(nodos):
    """
    Función para graficar los nodos en el espacio 2D.

    Parámetros:
    - nodos: lista de objetos Nodo.
    """
    fig, ax = plt.subplots()

    # Graficar nodos
    x = [nodo.x for nodo in nodos]
    y = [nodo.y for nodo in nodos]
    ax.scatter(x, y, c='red')

    # Añadir etiquetas a los nodos
    for nodo in nodos:
        ax.text(nodo.x, nodo.y, f'N{nodo.id}', fontsize=12, ha='right')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_title('Gráfico de Nodos')
    ax.grid(True)
    plt.show()
